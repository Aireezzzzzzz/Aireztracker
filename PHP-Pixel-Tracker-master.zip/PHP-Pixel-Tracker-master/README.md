# PHP Pixel Tracker
PHP pixel tracking

## How-to Use
Point to **image.php** using an &lt;img&gt; tag within your project.
```
<img src="./image.php?email=foo@bar.com">
```
